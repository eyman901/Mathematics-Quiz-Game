#include<iostream>
#include<string>
using namespace std;
const int Max=10;
int maxQuestion=5;
string questions[Max]={"1.8+1=?","2.2*4=?","3.12-6=?","4.6/2=?","5.2+2=?"};
	int ans[Max]={9,8,6,3,4};
	int userAns[Max];
	void createQuestion();
    void readQuestion();
    void updateQuestion(int);
    void deleteQuestion(int);
    void playQuiz();
    int main()
    {
	int choice;
	do{
		cout<<"    Mathematics Quiz Game Menu    "<<endl;
		cout<<"1. View Questions"<<endl;
		cout<<"2. Play quiz"<<endl;
		cout<<"3. Update a Question"<<endl;
		cout<<"4. Delete a Question"<<endl;
		cout<<"5. Create a Question"<<endl;
		cout<<"6. Exit"<<endl;
		cin>>choice;
		switch(choice){
		case 1: readQuestion();
		break;
		case 2: playQuiz();
		break;
		case 3: { int num;
		          cout<<"Enter the question num to update: ";
		          cin>>num;
		          updateQuestion(num-1);
		          break;}
		case 4:{int num;
		cout<<"Enter the question num to delete: ";
		cin>>num;
		deleteQuestion(num-1);
		break;}
		case 5: createQuestion();
		break;
		case 6: cout<<"Exiting";
		break;
		default: cout<<"Invalid choice"<<endl;}
	}while(choice !=6);
	return 0;}
	void playQuiz()
	{
		int score=0;
		for(int i=0;i<maxQuestion; i++){
		cout<<questions[i]<<endl;
		cin>> userAns[i];
		if (userAns[i]==ans[i])
		{
			score++;
		}}cout<<"Your score: "<<score<<"/"<<maxQuestion<<endl;
		if(score==maxQuestion)
	
		{
			cout<<"You got full marks."<<endl;}
			else{
			
			cout<<"You didn't get full marks."<<endl;
		}}
	
		void readQuestion()
		{
			cout<<"    All Questions    "<<endl;
			for(int i=0;i<maxQuestion;i++)
			{
				cout<<questions[i]<<endl;
			}
		}
		void updateQuestion(int a)
		{
			if(a<0 || a>=maxQuestion)
			{cout<<"Invalid"<<endl;
			return;}
			cin.ignore();
		cout<<"Enter the updated question: ";
		getline(cin, questions[a]);
		cout<<"Enter the updated correct answer: ";
		cin>>ans[a];
		cout<<"Question Updated successfully."<<endl;}
		
		void deleteQuestion(int a){
		if(a<0 || a >=maxQuestion){
		cout<<"Invalid "<<endl;
		return ;}
		for(int i=a;i<maxQuestion-1;i++)
		{
			questions[i]=questions[i+1];
		    ans[i]=ans[i+1];
		}
		maxQuestion--;
		cout<<"Question deleted successfully."<<endl;
		}
		void createQuestion()
		{
			if(maxQuestion>=Max)
			{
				cout<<"Cannot add more questions(limit reached).";
				return;
			}
			cout<<"Enter the question you want to add: "<<endl;
			cin.ignore();
			getline(cin,questions[maxQuestion]);
			cout<<"Enter the answer: "<<endl;
			cin>>ans[maxQuestion];
			maxQuestion++;
			cout<<"Question added succcessfully."<<endl;
		}
	
		
	